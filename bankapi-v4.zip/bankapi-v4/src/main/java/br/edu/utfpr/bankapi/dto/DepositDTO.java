package br.edu.utfpr.bankapi.dto;

public record DepositDTO(long receiverAccountNumber, double amount) {
}
